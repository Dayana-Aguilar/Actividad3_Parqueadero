package parqueadero.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import parqueadero.model.Vehiculo;

public class Parqueadero {

    private List<Vehiculo> vehiculos = new ArrayList<>();

    // Registrar entrada
    public void registrarEntrada(Vehiculo v) {
        vehiculos.add(v);
        System.out.println("Vehículo ingresado correctamente.");
    }

    // Registrar salida
    public void registrarSalida(String placa) {

        Vehiculo encontrado = null;

        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                encontrado = v;
                break;
            }
        }

        if (encontrado != null) {

            LocalDateTime horaSalida = LocalDateTime.now();

            long minutos = Duration.between(
                    encontrado.getHoraEntrada(),
                    horaSalida
            ).toMinutes();

            long horas = (long) Math.ceil(minutos / 60.0);

            double costo = horas * encontrado.calcularTarifaPorHora();

            vehiculos.remove(encontrado);

            System.out.println("Vehículo retirado.");
            System.out.println("Tiempo: " + horas + " horas.");
            System.out.println("Total a pagar: $" + costo);

        } else {
            System.out.println("Vehículo no encontrado.");
        }
    }

    // Mostrar vehículos actuales
    public void mostrarVehiculos() {

        if (vehiculos.isEmpty()) {
            System.out.println("No hay vehículos en el parqueadero.");
        } else {
            System.out.println("Vehículos en el parqueadero:");
            for (Vehiculo v : vehiculos) {
                System.out.println("- " + v.getPlaca() + " | " + v.getClass().getSimpleName());
            }
        }
    }
}

