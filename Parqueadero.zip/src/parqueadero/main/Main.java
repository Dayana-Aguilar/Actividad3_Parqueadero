package parqueadero.main;

import parqueadero.model.*;
import parqueadero.service.Parqueadero;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Parqueadero parqueadero = new Parqueadero();
        Scanner scanner = new Scanner(System.in);

        int opcion;

        do {
            System.out.println("\n--- MENU PARQUEADERO ---");
            System.out.println("1. Ingresar vehículo");
            System.out.println("2. Registrar salida");
            System.out.println("3. Mostrar vehículos");
            System.out.println("4. Salir");
            System.out.print("Seleccione opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {

                case 1:
                    System.out.println("Tipo (1-Automóvil, 2-Moto, 3-Camión): ");
                    int tipo = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Placa: ");
                    String placa = scanner.nextLine();

                    System.out.print("Marca: ");
                    String marca = scanner.nextLine();

                    System.out.print("Modelo: ");
                    String modelo = scanner.nextLine();

                    if (tipo == 1) {
                        System.out.print("Tipo combustible: ");
                        String combustible = scanner.nextLine();
                        parqueadero.registrarEntrada(
                                new Automovil(placa, marca, modelo, combustible)
                        );
                    } 
                    else if (tipo == 2) {
                        System.out.print("Cilindraje: ");
                        int cilindraje = scanner.nextInt();
                        parqueadero.registrarEntrada(
                                new Motocicleta(placa, marca, modelo, cilindraje)
                        );
                    } 
                    else if (tipo == 3) {
                        System.out.print("Capacidad carga (toneladas): ");
                        double carga = scanner.nextDouble();
                        parqueadero.registrarEntrada(
                                new Camion(placa, marca, modelo, carga)
                        );
                    }

                    break;

                case 2:
                    System.out.print("Placa del vehículo a retirar: ");
                    String placaSalida = scanner.nextLine();
                    parqueadero.registrarSalida(placaSalida);
                    break;

                case 3:
                    parqueadero.mostrarVehiculos();
                    break;

                case 4:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción inválida");
            }

        } while (opcion != 4);

        scanner.close();
    }
}


