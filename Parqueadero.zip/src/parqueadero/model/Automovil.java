package parqueadero.model;

public class Automovil extends Vehiculo {

    private String tipoCombustible;

    public Automovil(String placa, String marca, String modelo, String tipoCombustible) {
        super(placa, marca, modelo);
        this.tipoCombustible = tipoCombustible;
    }

    @Override
    public double calcularTarifaPorHora() {
        return 3000; // tarifa por hora
    }
}
