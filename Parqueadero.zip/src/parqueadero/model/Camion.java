package parqueadero.model;

public class Camion extends Vehiculo {

    private double capacidadCarga;

    public Camion(String placa, String marca, String modelo, double capacidadCarga) {
        super(placa, marca, modelo);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public double calcularTarifaPorHora() {
        return 7000; // tarifa por hora
    }
}
